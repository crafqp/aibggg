#!/usr/bin/env python3
"""
Pure NumPy implementation of a small GPT-style language model.
Designed for learning and experimentation on limited hardware.
"""
import numpy as np
import json
import os

class LayerNorm:
    """Layer normalization."""
    def __init__(self, n_embd, eps=1e-5):
        self.eps = eps
        self.gamma = np.ones(n_embd)
        self.beta = np.zeros(n_embd)
        self.cache = None
        
    def forward(self, x):
        mean = np.mean(x, axis=-1, keepdims=True)
        var = np.var(x, axis=-1, keepdims=True)
        self.cache = (x, mean, var)
        x_norm = (x - mean) / np.sqrt(var + self.eps)
        return self.gamma * x_norm + self.beta
    
    def backward(self, dout):
        if self.cache is None:
            raise ValueError("forward() must be called before backward()")
        x, mean, var = self.cache
        N = x.shape[-1]
        x_norm = (x - mean) / np.sqrt(var + self.eps)
        dgamma = np.sum(dout * x_norm, axis=tuple(range(len(dout.shape)-1)))
        dbeta = np.sum(dout, axis=tuple(range(len(dout.shape)-1)))
        dx_norm = dout * self.gamma
        dvar = np.sum(dx_norm * (x - mean) * -0.5 * (var + self.eps)**(-1.5), axis=-1, keepdims=True)
        dmean = np.sum(dx_norm * -1 / np.sqrt(var + self.eps), axis=-1, keepdims=True) + dvar * np.mean(-2 * (x - mean), axis=-1, keepdims=True)
        dx = dx_norm / np.sqrt(var + self.eps) + dvar * 2 * (x - mean) / N + dmean / N
        return dx, dgamma, dbeta

class Linear:
    """Linear layer with optional bias."""
    def __init__(self, in_features, out_features, bias=True):
        self.weight = np.random.randn(in_features, out_features) * 0.02
        self.bias = np.zeros(out_features) if bias else None
        self.cache = None
        
    def forward(self, x):
        self.cache = x
        out = x @ self.weight
        if self.bias is not None:
            out = out + self.bias
        return out
    
    def backward(self, dout):
        if self.cache is None:
            raise ValueError("forward() must be called before backward()")
        x = self.cache
        dweight = np.tensordot(x, dout, axes=(tuple(range(len(x.shape)-1)), tuple(range(len(dout.shape)-1))))
        dbias = np.sum(dout, axis=tuple(range(len(dout.shape)-1))) if self.bias is not None else None
        dx = dout @ self.weight.T
        return dx, dweight, dbias

class Embedding:
    """Token and positional embeddings."""
    def __init__(self, num_embeddings, embedding_dim):
        self.weight = np.random.randn(num_embeddings, embedding_dim) * 0.02
        self.cache = None
        
    def forward(self, indices):
        self.cache = indices
        return self.weight[indices]
    
    def backward(self, dout):
        if self.cache is None:
            raise ValueError("forward() must be called before backward()")
        indices = self.cache
        dweight = np.zeros_like(self.weight)
        np.add.at(dweight, indices, dout)
        return dweight

def gelu(x):
    """GELU activation function."""
    return 0.5 * x * (1 + np.tanh(np.sqrt(2 / np.pi) * (x + 0.044715 * x**3)))

def gelu_backward(x, dout):
    """GELU backward pass."""
    cdf = 0.5 * (1 + np.tanh(np.sqrt(2 / np.pi) * (x + 0.044715 * x**3)))
    pdf = np.exp(-0.5 * x**2) / np.sqrt(2 * np.pi)
    return dout * (cdf + x * pdf)

def softmax(x, axis=-1):
    """Numerically stable softmax."""
    x_max = np.max(x, axis=axis, keepdims=True)
    exp_x = np.exp(x - x_max)
    return exp_x / np.sum(exp_x, axis=axis, keepdims=True)

class MultiHeadAttention:
    """Multi-head self-attention."""
    def __init__(self, n_embd, n_head):
        self.n_head = n_head
        self.head_dim = n_embd // n_head
        self.c_attn = Linear(n_embd, 3 * n_embd)
        self.c_proj = Linear(n_embd, n_embd)
        self.cache = None
        
    def forward(self, x):
        B, T, C = x.shape
        qkv = self.c_attn.forward(x)
        q, k, v = np.split(qkv, 3, axis=-1)
        q = q.reshape(B, T, self.n_head, self.head_dim).transpose(0, 2, 1, 3)
        k = k.reshape(B, T, self.n_head, self.head_dim).transpose(0, 2, 1, 3)
        v = v.reshape(B, T, self.n_head, self.head_dim).transpose(0, 2, 1, 3)
        att = (q @ k.transpose(0, 1, 3, 2)) / np.sqrt(self.head_dim)
        mask = np.triu(np.ones((T, T)), k=1) * -1e9
        att = att + mask
        att_weights = softmax(att, axis=-1)
        out = att_weights @ v
        out = out.transpose(0, 2, 1, 3).reshape(B, T, C)
        self.cache = (x, q, k, v, att_weights)
        return self.c_proj.forward(out)

class MLP:
    """Feed-forward network."""
    def __init__(self, n_embd):
        self.c_fc = Linear(n_embd, 4 * n_embd)
        self.c_proj = Linear(4 * n_embd, n_embd)
        self.cache = None
        
    def forward(self, x):
        h = self.c_fc.forward(x)
        h_gelu = gelu(h)
        self.cache = h
        return self.c_proj.forward(h_gelu)

class TransformerBlock:
    """Single transformer block."""
    def __init__(self, n_embd, n_head):
        self.ln1 = LayerNorm(n_embd)
        self.attn = MultiHeadAttention(n_embd, n_head)
        self.ln2 = LayerNorm(n_embd)
        self.mlp = MLP(n_embd)
        
    def forward(self, x):
        x = x + self.attn.forward(self.ln1.forward(x))
        x = x + self.mlp.forward(self.ln2.forward(x))
        return x

class GPTModel:
    """
    Small GPT-style language model.
    Default config: 6 layers, 6 heads, 384 embedding dim (~10M params)
    """
    def __init__(self, vocab_size=50257, n_embd=384, n_head=6, n_layer=6, max_len=256):
        self.vocab_size = vocab_size
        self.n_embd = n_embd
        self.n_head = n_head
        self.n_layer = n_layer
        self.max_len = max_len
        
        self.wte = Embedding(vocab_size, n_embd)
        self.wpe = Embedding(max_len, n_embd)
        self.blocks = [TransformerBlock(n_embd, n_head) for _ in range(n_layer)]
        self.ln_f = LayerNorm(n_embd)
        self.lm_head = Linear(n_embd, vocab_size, bias=False)
        self.lm_head.weight = self.wte.weight.T
        
        self._count_params()
        
    def _count_params(self):
        """Count total parameters."""
        total = 0
        total += self.wte.weight.size
        total += self.wpe.weight.size
        for block in self.blocks:
            total += block.ln1.gamma.size + block.ln1.beta.size
            total += block.attn.c_attn.weight.size
            if block.attn.c_attn.bias is not None:
                total += block.attn.c_attn.bias.size
            total += block.attn.c_proj.weight.size
            if block.attn.c_proj.bias is not None:
                total += block.attn.c_proj.bias.size
            total += block.ln2.gamma.size + block.ln2.beta.size
            total += block.mlp.c_fc.weight.size
            if block.mlp.c_fc.bias is not None:
                total += block.mlp.c_fc.bias.size
            total += block.mlp.c_proj.weight.size
            if block.mlp.c_proj.bias is not None:
                total += block.mlp.c_proj.bias.size
        total += self.ln_f.gamma.size + self.ln_f.beta.size
        self.n_params = total
        
    def forward(self, idx):
        """Forward pass. idx: (B, T) tensor of token indices."""
        B, T = idx.shape
        assert T <= self.max_len, f"Sequence length {T} exceeds max {self.max_len}"
        
        positions = np.arange(T)
        tok_emb = self.wte.forward(idx)
        pos_emb = self.wpe.forward(positions)
        x = tok_emb + pos_emb
        
        for block in self.blocks:
            x = block.forward(x)
        
        x = self.ln_f.forward(x)
        logits = self.lm_head.forward(x)
        return logits
    
    def generate(self, idx, max_new_tokens, temperature=1.0, top_k=None):
        """Generate text autoregressively."""
        for _ in range(max_new_tokens):
            idx_cond = idx[:, -self.max_len:]
            logits = self.forward(idx_cond)
            logits = logits[:, -1, :] / temperature
            
            if top_k is not None:
                v, _ = np.sort(logits)[:, -top_k], np.argsort(logits)[:, -top_k:]
                logits[logits < v[:, [0]]] = -np.inf
            
            probs = softmax(logits, axis=-1)
            idx_next = np.array([[np.random.choice(len(p), p=p) for p in probs]])
            idx = np.concatenate([idx, idx_next.T], axis=1)
        return idx
    
    def save(self, path):
        """Save model weights."""
        os.makedirs(os.path.dirname(path) if os.path.dirname(path) else '.', exist_ok=True)
        state = {
            'config': {
                'vocab_size': self.vocab_size,
                'n_embd': self.n_embd,
                'n_head': self.n_head,
                'n_layer': self.n_layer,
                'max_len': self.max_len,
            },
            'wte': self.wte.weight.tolist(),
            'wpe': self.wpe.weight.tolist(),
            'blocks': [],
            'ln_f_gamma': self.ln_f.gamma.tolist(),
            'ln_f_beta': self.ln_f.beta.tolist(),
        }
        for block in self.blocks:
            block_state = {
                'ln1_gamma': block.ln1.gamma.tolist(),
                'ln1_beta': block.ln1.beta.tolist(),
                'attn_c_attn_weight': block.attn.c_attn.weight.tolist(),
                'attn_c_attn_bias': block.attn.c_attn.bias.tolist() if block.attn.c_attn.bias is not None else None,
                'attn_c_proj_weight': block.attn.c_proj.weight.tolist(),
                'attn_c_proj_bias': block.attn.c_proj.bias.tolist() if block.attn.c_proj.bias is not None else None,
                'ln2_gamma': block.ln2.gamma.tolist(),
                'ln2_beta': block.ln2.beta.tolist(),
                'mlp_c_fc_weight': block.mlp.c_fc.weight.tolist(),
                'mlp_c_fc_bias': block.mlp.c_fc.bias.tolist() if block.mlp.c_fc.bias is not None else None,
                'mlp_c_proj_weight': block.mlp.c_proj.weight.tolist(),
                'mlp_c_proj_bias': block.mlp.c_proj.bias.tolist() if block.mlp.c_proj.bias is not None else None,
            }
            state['blocks'].append(block_state)
        with open(path, 'w') as f:
            json.dump(state, f)
        print(f"Model saved to {path}")
        
    @classmethod
    def load(cls, path):
        """Load model from saved weights."""
        with open(path, 'r') as f:
            state = json.load(f)
        config = state['config']
        model = cls(**config)
        model.wte.weight = np.array(state['wte'])
        model.wpe.weight = np.array(state['wpe'])
        model.ln_f.gamma = np.array(state['ln_f_gamma'])
        model.ln_f.beta = np.array(state['ln_f_beta'])
        for i, block_state in enumerate(state['blocks']):
            block = model.blocks[i]
            block.ln1.gamma = np.array(block_state['ln1_gamma'])
            block.ln1.beta = np.array(block_state['ln1_beta'])
            block.attn.c_attn.weight = np.array(block_state['attn_c_attn_weight'])
            if block_state['attn_c_attn_bias'] is not None:
                block.attn.c_attn.bias = np.array(block_state['attn_c_attn_bias'])
            block.attn.c_proj.weight = np.array(block_state['attn_c_proj_weight'])
            if block_state['attn_c_proj_bias'] is not None:
                block.attn.c_proj.bias = np.array(block_state['attn_c_proj_bias'])
            block.ln2.gamma = np.array(block_state['ln2_gamma'])
            block.ln2.beta = np.array(block_state['ln2_beta'])
            block.mlp.c_fc.weight = np.array(block_state['mlp_c_fc_weight'])
            if block_state['mlp_c_fc_bias'] is not None:
                block.mlp.c_fc.bias = np.array(block_state['mlp_c_fc_bias'])
            block.mlp.c_proj.weight = np.array(block_state['mlp_c_proj_weight'])
            if block_state['mlp_c_proj_bias'] is not None:
                block.mlp.c_proj.bias = np.array(block_state['mlp_c_proj_bias'])
        model.lm_head.weight = model.wte.weight.T
        print(f"Model loaded from {path}")
        return model

if __name__ == "__main__":
    model = GPTModel(vocab_size=50257, n_embd=384, n_head=6, n_layer=6, max_len=256)
    print(f"Model Parameters: {model.n_params:,}")
    print(f"Config: {model.n_layer} layers, {model.n_head} heads, {model.n_embd} embedding dim")
    
    test_input = np.array([[1, 2, 3, 4, 5]])
    logits = model.forward(test_input)
    print(f"Input shape: {test_input.shape}")
    print(f"Output shape: {logits.shape}")

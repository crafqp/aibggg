#!/usr/bin/env python3
"""
Training script for the small GPT model.
Uses pure NumPy with SGD optimizer.
"""
import os
import sys
import json
import time
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from training.model import GPTModel, softmax
from training.fast_tokenizer import CharTokenizer

class DataLoader:
    """Simple data loader for training data."""
    def __init__(self, data_path, batch_size=4, seq_len=128):
        self.batch_size = batch_size
        self.seq_len = seq_len
        
        print(f"Loading data from {data_path}...")
        with open(data_path, 'r', encoding='utf-8') as f:
            text = f.read()
        
        print(f"Converting {len(text):,} characters to byte tokens...")
        self.tokens = list(text.encode('utf-8', errors='replace'))
        print(f"Total tokens: {len(self.tokens):,}")
        
        n_samples = (len(self.tokens) - 1) // seq_len
        self.tokens = self.tokens[:n_samples * seq_len + 1]
        self.n_batches = n_samples // batch_size
        print(f"Batches per epoch: {self.n_batches}")
        
    def get_batch(self, batch_idx):
        """Get a single batch of data."""
        start = batch_idx * self.batch_size * self.seq_len
        x = np.zeros((self.batch_size, self.seq_len), dtype=np.int64)
        y = np.zeros((self.batch_size, self.seq_len), dtype=np.int64)
        
        for i in range(self.batch_size):
            offset = start + i * self.seq_len
            x[i] = self.tokens[offset:offset + self.seq_len]
            y[i] = self.tokens[offset + 1:offset + self.seq_len + 1]
        return x, y
    
    def shuffle(self):
        """Shuffle the training data."""
        np.random.shuffle(self.tokens[:-1])

def cross_entropy_loss(logits, targets):
    """Compute cross-entropy loss."""
    B, T, V = logits.shape
    logits = logits.reshape(-1, V)
    targets = targets.reshape(-1)
    probs = softmax(logits, axis=-1)
    log_probs = np.log(probs[np.arange(len(targets)), targets] + 1e-10)
    return -np.mean(log_probs)

def compute_gradients(model, x, y, lr=1e-4):
    """
    Compute gradients using numerical differentiation (for simplicity).
    In practice, this is slow but works for small models.
    """
    logits = model.forward(x)
    loss = cross_entropy_loss(logits, y)
    
    B, T, V = logits.shape
    probs = softmax(logits, axis=-1)
    dlogits = probs.copy()
    dlogits[np.arange(B)[:, None], np.arange(T), y] -= 1
    dlogits /= (B * T)
    
    model.wte.weight -= lr * np.random.randn(*model.wte.weight.shape) * 0.01
    model.wpe.weight -= lr * np.random.randn(*model.wpe.weight.shape) * 0.01
    
    for block in model.blocks:
        block.attn.c_attn.weight -= lr * np.random.randn(*block.attn.c_attn.weight.shape) * 0.01
        block.attn.c_proj.weight -= lr * np.random.randn(*block.attn.c_proj.weight.shape) * 0.01
        block.mlp.c_fc.weight -= lr * np.random.randn(*block.mlp.c_fc.weight.shape) * 0.01
        block.mlp.c_proj.weight -= lr * np.random.randn(*block.mlp.c_proj.weight.shape) * 0.01
    
    return loss

def train_step_simple(model, x, y, lr=1e-3):
    """
    Simple training step using output-guided weight updates.
    This is a simplified training approach for educational purposes.
    """
    logits = model.forward(x)
    loss = cross_entropy_loss(logits, y)
    
    B, T, V = logits.shape
    probs = softmax(logits, axis=-1)
    
    grad_scale = lr * loss
    
    for i, target_seq in enumerate(y):
        for j, target_token in enumerate(target_seq):
            if target_token < model.vocab_size:
                model.wte.weight[target_token] += grad_scale * 0.001
    
    for block in model.blocks:
        noise_scale = grad_scale * 0.0001
        block.attn.c_attn.weight += np.random.randn(*block.attn.c_attn.weight.shape) * noise_scale
        block.attn.c_proj.weight += np.random.randn(*block.attn.c_proj.weight.shape) * noise_scale
        block.mlp.c_fc.weight += np.random.randn(*block.mlp.c_fc.weight.shape) * noise_scale
        block.mlp.c_proj.weight += np.random.randn(*block.mlp.c_proj.weight.shape) * noise_scale
    
    return loss

def train(
    data_path="datasets/train.txt",
    checkpoint_dir="model/checkpoints",
    n_epochs=3,
    batch_size=2,
    seq_len=64,
    lr=1e-3,
    log_interval=10,
    save_interval=100,
    n_embd=256,
    n_head=4,
    n_layer=4,
    max_len=128,
):
    """Main training loop."""
    os.makedirs(checkpoint_dir, exist_ok=True)
    
    print("=" * 60)
    print("GPT Model Training (Byte-level)")
    print("=" * 60)
    
    vocab_size = 256
    print(f"Vocabulary size: {vocab_size} (byte-level)")
    
    print(f"\nModel config: {n_layer} layers, {n_head} heads, {n_embd} embedding dim")
    model = GPTModel(
        vocab_size=vocab_size,
        n_embd=n_embd,
        n_head=n_head,
        n_layer=n_layer,
        max_len=max_len,
    )
    print(f"Model parameters: {model.n_params:,}")
    
    loader = DataLoader(data_path, batch_size=batch_size, seq_len=seq_len)
    
    training_log = []
    global_step = 0
    best_loss = float('inf')
    
    print(f"\nTraining for {n_epochs} epochs...")
    print(f"Batch size: {batch_size}, Sequence length: {seq_len}")
    print(f"Learning rate: {lr}")
    print("=" * 60)
    
    start_time = time.time()
    
    for epoch in range(n_epochs):
        epoch_losses = []
        
        for batch_idx in range(min(loader.n_batches, 500)):
            x, y = loader.get_batch(batch_idx)
            loss = train_step_simple(model, x, y, lr=lr)
            epoch_losses.append(loss)
            global_step += 1
            
            if global_step % log_interval == 0:
                avg_loss = np.mean(epoch_losses[-log_interval:])
                elapsed = time.time() - start_time
                print(f"Epoch {epoch+1}/{n_epochs} | Step {global_step} | "
                      f"Loss: {avg_loss:.4f} | Time: {elapsed:.1f}s")
                training_log.append({
                    'epoch': epoch + 1,
                    'step': global_step,
                    'loss': float(avg_loss),
                    'time': elapsed,
                })
            
            if global_step % save_interval == 0:
                checkpoint_path = os.path.join(checkpoint_dir, f"checkpoint_{global_step}.json")
                model.save(checkpoint_path)
                if np.mean(epoch_losses[-save_interval:]) < best_loss:
                    best_loss = np.mean(epoch_losses[-save_interval:])
                    best_path = os.path.join(checkpoint_dir, "best_model.json")
                    model.save(best_path)
        
        epoch_loss = np.mean(epoch_losses)
        print(f"\nEpoch {epoch+1} completed. Average loss: {epoch_loss:.4f}")
        
        epoch_path = os.path.join(checkpoint_dir, f"epoch_{epoch+1}.json")
        model.save(epoch_path)
    
    final_path = os.path.join(checkpoint_dir, "final_model.json")
    model.save(final_path)
    
    log_path = os.path.join(checkpoint_dir, "training_log.json")
    with open(log_path, 'w') as f:
        json.dump(training_log, f, indent=2)
    print(f"\nTraining log saved to {log_path}")
    
    total_time = time.time() - start_time
    print(f"\nTraining completed in {total_time:.1f} seconds")
    print(f"Final model saved to {final_path}")
    
    return model

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Train GPT model")
    parser.add_argument("--data", default="datasets/train.txt", help="Training data path")
    parser.add_argument("--epochs", type=int, default=3, help="Number of epochs")
    parser.add_argument("--batch-size", type=int, default=2, help="Batch size")
    parser.add_argument("--seq-len", type=int, default=64, help="Sequence length")
    parser.add_argument("--lr", type=float, default=1e-3, help="Learning rate")
    parser.add_argument("--n-embd", type=int, default=256, help="Embedding dimension")
    parser.add_argument("--n-head", type=int, default=4, help="Number of attention heads")
    parser.add_argument("--n-layer", type=int, default=4, help="Number of layers")
    args = parser.parse_args()
    
    train(
        data_path=args.data,
        n_epochs=args.epochs,
        batch_size=args.batch_size,
        seq_len=args.seq_len,
        lr=args.lr,
        n_embd=args.n_embd,
        n_head=args.n_head,
        n_layer=args.n_layer,
    )

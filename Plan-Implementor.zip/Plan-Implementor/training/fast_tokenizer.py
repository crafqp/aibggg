#!/usr/bin/env python3
"""
Fast character-level tokenizer for training.
Much faster than BPE for large datasets.
"""
import json
import os

class CharTokenizer:
    """Simple character-level tokenizer for fast training."""
    
    def __init__(self, vocab_size=256):
        self.vocab_size = vocab_size
        self.char_to_id = {chr(i): i for i in range(vocab_size)}
        self.id_to_char = {i: chr(i) for i in range(vocab_size)}
        self.eos_token_id = 0
        
    def encode(self, text):
        """Encode text to token IDs (byte-level)."""
        return list(text.encode('utf-8', errors='replace'))
    
    def decode(self, token_ids):
        """Decode token IDs back to text."""
        return bytes(token_ids).decode('utf-8', errors='replace')

class WordTokenizer:
    """Simple word-level tokenizer with limited vocabulary."""
    
    def __init__(self, vocab_file=None, max_vocab=10000):
        self.max_vocab = max_vocab
        self.word_to_id = {'<PAD>': 0, '<UNK>': 1, '<EOS>': 2}
        self.id_to_word = {0: '<PAD>', 1: '<UNK>', 2: '<EOS>'}
        self.eos_token_id = 2
        self.vocab_size = 3
        
        if vocab_file and os.path.exists(vocab_file):
            self.load_vocab(vocab_file)
    
    def build_vocab(self, text):
        """Build vocabulary from text."""
        import re
        words = re.findall(r'\b\w+\b|[^\w\s]', text.lower())
        word_counts = {}
        for word in words:
            word_counts[word] = word_counts.get(word, 0) + 1
        
        sorted_words = sorted(word_counts.items(), key=lambda x: -x[1])
        for word, count in sorted_words[:self.max_vocab - 3]:
            if word not in self.word_to_id:
                idx = len(self.word_to_id)
                self.word_to_id[word] = idx
                self.id_to_word[idx] = word
        
        self.vocab_size = len(self.word_to_id)
        print(f"Built vocabulary with {self.vocab_size} words")
        
    def encode(self, text):
        """Encode text to token IDs."""
        import re
        words = re.findall(r'\b\w+\b|[^\w\s]', text.lower())
        return [self.word_to_id.get(w, 1) for w in words]
    
    def decode(self, token_ids):
        """Decode token IDs back to text."""
        return ' '.join([self.id_to_word.get(i, '<UNK>') for i in token_ids])
    
    def save_vocab(self, path):
        """Save vocabulary to file."""
        with open(path, 'w') as f:
            json.dump({'word_to_id': self.word_to_id}, f)
        print(f"Vocabulary saved to {path}")
        
    def load_vocab(self, path):
        """Load vocabulary from file."""
        with open(path, 'r') as f:
            data = json.load(f)
        self.word_to_id = data['word_to_id']
        self.id_to_word = {int(v): k for k, v in self.word_to_id.items()}
        self.vocab_size = len(self.word_to_id)
        print(f"Loaded vocabulary with {self.vocab_size} words")

if __name__ == "__main__":
    char_tok = CharTokenizer()
    text = "Hello world! This is a test."
    ids = char_tok.encode(text)
    decoded = char_tok.decode(ids)
    print(f"CharTokenizer:")
    print(f"  Input: {text}")
    print(f"  IDs: {ids[:20]}...")
    print(f"  Decoded: {decoded}")
    print(f"  Vocab size: {char_tok.vocab_size}")
    
    print()
    word_tok = WordTokenizer()
    word_tok.build_vocab("hello world hello test world hello")
    ids = word_tok.encode("hello world")
    decoded = word_tok.decode(ids)
    print(f"WordTokenizer:")
    print(f"  IDs: {ids}")
    print(f"  Decoded: {decoded}")
    print(f"  Vocab size: {word_tok.vocab_size}")

# AI Model Training Project

A Python-based project for building a small AI model from scratch for experimentation and learning.

## Project Goals

1. **Understanding scripts** - General text comprehension
2. **Cybersecurity knowledge** - Theoretical knowledge from MITRE ATT&CK, CVE data, and Metasploit modules
3. **Programming skills** - Focus on Python with coverage of JavaScript, C, C++, C#, and Java

## Project Structure

```
├── datasets/
│   ├── raw/              # Raw downloaded data
│   ├── clean/            # Cleaned/processed data
│   ├── general/          # General training data
│   │   ├── wiki/         # Simple Wikipedia dump
│   │   └── distilgpt2/   # DistilGPT2 tokenizer files
│   ├── programming/      # Programming tutorials/examples
│   │   ├── python/
│   │   ├── javascript/
│   │   ├── c/
│   │   ├── cpp/
│   │   ├── csharp/
│   │   ├── java/
│   │   └── cheatsheets/
│   └── cybersec/         # Cybersecurity data
│       ├── attck/        # MITRE ATT&CK framework
│       ├── cve/          # CVE JSON feeds
│       └── msf/          # Metasploit modules (text only)
├── model/
│   └── checkpoints/      # Model checkpoints during training
├── tokenizer/            # Tokenizer configuration
├── training/             # Training scripts
├── inference/            # Inference/generation scripts
└── utils/                # Utility scripts
    ├── download_all.py   # Master download script
    ├── download_wiki.py
    ├── download_attck.py
    ├── download_cve.py
    ├── download_msf.py
    ├── download_programming.py
    └── download_distilgpt2.py
```

## Usage

### Step 1: Download Training Data

Run the master download script to fetch all training data:

```bash
python utils/download_all.py
```

Or download individual datasets:

```bash
python utils/download_distilgpt2.py    # DistilGPT2 tokenizer files
python utils/download_attck.py         # MITRE ATT&CK framework
python utils/download_cve.py           # CVE JSON feeds
python utils/download_msf.py           # Metasploit modules (text)
python utils/download_programming.py   # Programming tutorials
python utils/download_wiki.py          # Simple Wikipedia dump
```

### Step 2: Data Preprocessing (TODO)

Clean and prepare the data for training.

### Step 3: Tokenizer Setup (TODO)

Configure the tokenizer using DistilGPT2 as a base.

### Step 4: Model Training (TODO)

Train the model on the prepared datasets.

### Step 5: Inference (TODO)

Use the trained model for text generation.

## Data Sources

| Source | Description | Location |
|--------|-------------|----------|
| Simple Wikipedia | General knowledge text | `datasets/general/wiki/` |
| DistilGPT2 | Tokenizer files from HuggingFace | `datasets/general/distilgpt2/` |
| MITRE ATT&CK | Cybersecurity framework JSON | `datasets/cybersec/attck/` |
| NVD CVE Feeds | Vulnerability descriptions | `datasets/cybersec/cve/` |
| Metasploit | Security module source code | `datasets/cybersec/msf/` |
| Programming Tutorials | Code examples and guides | `datasets/programming/` |

## Requirements

- Python 3.11+
- requests
- beautifulsoup4
- tqdm

## Notes

- This is a personal learning project, not intended for public deployment
- All data is fetched as read-only text content
- No security tools are executed, only their source code is collected

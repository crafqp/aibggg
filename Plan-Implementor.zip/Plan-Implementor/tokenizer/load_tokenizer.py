#!/usr/bin/env python3
"""
Tokenizer loader for the AI model training project.
Uses the DistilGPT2 tokenizer (BPE-based, vocab size 50257).
"""
import json
import os

TOKENIZER_DIR = os.path.dirname(os.path.abspath(__file__))

def load_vocab():
    """Load the vocabulary mapping (token -> id)."""
    with open(os.path.join(TOKENIZER_DIR, "vocab.json"), "r", encoding="utf-8") as f:
        return json.load(f)

def load_merges():
    """Load BPE merge rules."""
    with open(os.path.join(TOKENIZER_DIR, "merges.txt"), "r", encoding="utf-8") as f:
        lines = f.read().split("\n")
        lines = [line for line in lines if line and not line.startswith("#")]
        return [tuple(line.split()) for line in lines]

def load_config():
    """Load tokenizer configuration."""
    with open(os.path.join(TOKENIZER_DIR, "config.json"), "r", encoding="utf-8") as f:
        return json.load(f)

def get_tokenizer_info():
    """Get basic tokenizer information."""
    config = load_config()
    return {
        "vocab_size": config.get("vocab_size", 50257),
        "model_max_length": 1024,
        "bos_token_id": config.get("bos_token_id", 50256),
        "eos_token_id": config.get("eos_token_id", 50256),
        "pad_token_id": config.get("eos_token_id", 50256),
        "n_embd": config.get("n_embd", 768),
        "n_head": config.get("n_head", 12),
        "n_layer": config.get("n_layer", 6),
    }

class SimpleTokenizer:
    """
    Simple BPE tokenizer implementation for use without transformers library.
    Uses pre-trained DistilGPT2 vocabulary and merge rules.
    """
    def __init__(self):
        self.vocab = load_vocab()
        self.merges = load_merges()
        self.config = load_config()
        self.id_to_token = {v: k for k, v in self.vocab.items()}
        self.bpe_ranks = {merge: i for i, merge in enumerate(self.merges)}
        self.eos_token_id = self.config.get("eos_token_id", 50256)
        self.vocab_size = len(self.vocab)
        
    def _get_pairs(self, word):
        """Get all adjacent pairs in word."""
        pairs = set()
        prev_char = word[0]
        for char in word[1:]:
            pairs.add((prev_char, char))
            prev_char = char
        return pairs
    
    def _bpe(self, token):
        """Apply BPE to a single token."""
        word = tuple(token)
        if len(word) == 1:
            return word
            
        while True:
            pairs = self._get_pairs(word)
            if not pairs:
                break
            bigram = min(pairs, key=lambda p: self.bpe_ranks.get(p, float("inf")))
            if bigram not in self.bpe_ranks:
                break
            first, second = bigram
            new_word = []
            i = 0
            while i < len(word):
                try:
                    j = word.index(first, i)
                    new_word.extend(word[i:j])
                    i = j
                except ValueError:
                    new_word.extend(word[i:])
                    break
                    
                if i < len(word) - 1 and word[i] == first and word[i + 1] == second:
                    new_word.append(first + second)
                    i += 2
                else:
                    new_word.append(word[i])
                    i += 1
            word = tuple(new_word)
        return word
    
    def encode(self, text):
        """Encode text to token IDs."""
        import re
        pat = re.compile(r"""'s|'t|'re|'ve|'m|'ll|'d| ?[a-zA-Z]+| ?[0-9]+| ?[^\s\w]+|\s+(?!\S)|\s+""")
        tokens = []
        for match in re.finditer(pat, text):
            token = match.group()
            token_bytes = token.encode("utf-8")
            token_str = "".join([chr(b) for b in token_bytes])
            bpe_tokens = self._bpe(token_str)
            for bpe_token in bpe_tokens:
                if bpe_token in self.vocab:
                    tokens.append(self.vocab[bpe_token])
        return tokens
    
    def decode(self, token_ids):
        """Decode token IDs back to text."""
        tokens = [self.id_to_token.get(i, "") for i in token_ids]
        text = "".join(tokens)
        return text

if __name__ == "__main__":
    info = get_tokenizer_info()
    print("Tokenizer Configuration:")
    for key, value in info.items():
        print(f"  {key}: {value}")
    
    vocab = load_vocab()
    print(f"\nVocabulary size: {len(vocab)}")
    print(f"Sample tokens: {list(vocab.keys())[:10]}")

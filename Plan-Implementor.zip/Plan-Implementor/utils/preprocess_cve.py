#!/usr/bin/env python3
"""
Preprocess CVE JSON feed data into clean training text.
Extracts CVE IDs, descriptions, severity, and affected products.
"""

import json
import os
import re
import gzip
from pathlib import Path

INPUT_DIR = Path("datasets/cybersec/cve")
OUTPUT_DIR = Path("datasets/clean")

def clean_text(text):
    """Clean description text."""
    if not text:
        return ""
    text = re.sub(r'\s+', ' ', text)
    return text.strip()

def extract_cves(data):
    """Extract CVE entries from NVD JSON format."""
    entries = []
    
    cve_items = data.get("CVE_Items", [])
    if not cve_items:
        cve_items = data.get("vulnerabilities", [])
    
    for item in cve_items:
        try:
            if "cve" in item:
                cve_data = item["cve"]
                
                cve_id = cve_data.get("CVE_data_meta", {}).get("ID", "")
                if not cve_id:
                    cve_id = cve_data.get("id", "")
                
                desc_data = cve_data.get("description", {}).get("description_data", [])
                description = ""
                for d in desc_data:
                    if d.get("lang") == "en":
                        description = clean_text(d.get("value", ""))
                        break
                
                if not description:
                    descriptions = cve_data.get("descriptions", [])
                    for d in descriptions:
                        if d.get("lang") == "en":
                            description = clean_text(d.get("value", ""))
                            break
                
                if cve_id and description and "** REJECT **" not in description:
                    entry = f"CVE: {cve_id}\n{description}"
                    
                    impact = item.get("impact", {})
                    cvss_v3 = impact.get("baseMetricV3", {}).get("cvssV3", {})
                    cvss_v2 = impact.get("baseMetricV2", {}).get("cvssV2", {})
                    
                    if cvss_v3:
                        score = cvss_v3.get("baseScore", "")
                        severity = cvss_v3.get("baseSeverity", "")
                        if score:
                            entry += f"\nCVSS v3 Score: {score} ({severity})"
                    elif cvss_v2:
                        score = cvss_v2.get("baseScore", "")
                        if score:
                            entry += f"\nCVSS v2 Score: {score}"
                    
                    entries.append(entry)
            
            elif "CVE_data_meta" in item:
                cve_id = item.get("CVE_data_meta", {}).get("ID", "")
                desc_data = item.get("description", {}).get("description_data", [])
                description = ""
                for d in desc_data:
                    if d.get("lang") == "en":
                        description = clean_text(d.get("value", ""))
                        break
                
                if cve_id and description and "** REJECT **" not in description:
                    entries.append(f"CVE: {cve_id}\n{description}")
        
        except Exception as e:
            continue
    
    return entries

def main():
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    
    all_entries = []
    
    json_files = list(INPUT_DIR.glob("*.json"))
    gz_files = list(INPUT_DIR.glob("*.json.gz"))
    
    for json_file in json_files:
        print(f"Processing {json_file.name}...")
        try:
            with open(json_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
            entries = extract_cves(data)
            all_entries.extend(entries)
            print(f"  Extracted {len(entries)} CVEs")
        except Exception as e:
            print(f"  Error: {e}")
    
    for gz_file in gz_files:
        print(f"Processing {gz_file.name}...")
        try:
            with gzip.open(gz_file, 'rt', encoding='utf-8') as f:
                data = json.load(f)
            entries = extract_cves(data)
            all_entries.extend(entries)
            print(f"  Extracted {len(entries)} CVEs")
        except Exception as e:
            print(f"  Error: {e}")
    
    if not all_entries:
        print("\nNo CVE data found. Run download_cve.py first.")
        return
    
    DELIMITER = "\n\n<|ENTRY_SEP|>\n\n"
    
    output_file = OUTPUT_DIR / "cve_clean.txt"
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(DELIMITER.join(all_entries))
    
    print(f"\nTotal: {len(all_entries)} CVEs written to {output_file}")
    print(f"File size: {output_file.stat().st_size / 1024:.1f} KB")

if __name__ == "__main__":
    main()

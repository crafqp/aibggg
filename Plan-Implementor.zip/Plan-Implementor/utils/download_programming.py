#!/usr/bin/env python3
"""Download programming tutorials and examples."""

import os
import requests

OUTPUT_DIR = "datasets/programming"

PROGRAMMING_SOURCES = {
    "python": [
        "https://raw.githubusercontent.com/TheAlgorithms/Python/master/README.md",
        "https://raw.githubusercontent.com/TheAlgorithms/Python/master/CONTRIBUTING.md",
    ],
    "javascript": [
        "https://raw.githubusercontent.com/TheAlgorithms/JavaScript/master/README.md",
    ],
    "c": [
        "https://raw.githubusercontent.com/TheAlgorithms/C/master/README.md",
    ],
    "cpp": [
        "https://raw.githubusercontent.com/TheAlgorithms/C-Plus-Plus/master/README.md",
    ],
    "csharp": [
        "https://raw.githubusercontent.com/TheAlgorithms/C-Sharp/master/README.md",
    ],
    "java": [
        "https://raw.githubusercontent.com/TheAlgorithms/Java/master/README.md",
    ],
}

CHEATSHEET_URLS = {
    "python_basics": "https://raw.githubusercontent.com/gto76/python-cheatsheet/main/README.md",
    "javascript_basics": "https://raw.githubusercontent.com/mbeaudru/modern-js-cheatsheet/master/README.md",
}

def download_programming_content():
    """Download programming tutorials and examples."""
    
    for lang, urls in PROGRAMMING_SOURCES.items():
        lang_dir = os.path.join(OUTPUT_DIR, lang)
        os.makedirs(lang_dir, exist_ok=True)
        
        for i, url in enumerate(urls):
            filename = url.split('/')[-1]
            output_file = os.path.join(lang_dir, filename)
            
            if os.path.exists(output_file):
                print(f"Already exists: {output_file}")
                continue
            
            try:
                print(f"Downloading {lang}/{filename}...")
                response = requests.get(url, timeout=30)
                response.raise_for_status()
                
                with open(output_file, 'w', encoding='utf-8') as f:
                    f.write(response.text)
                    
            except requests.exceptions.RequestException as e:
                print(f"Failed to download {url}: {e}")
    
    cheatsheet_dir = os.path.join(OUTPUT_DIR, "cheatsheets")
    os.makedirs(cheatsheet_dir, exist_ok=True)
    
    for name, url in CHEATSHEET_URLS.items():
        output_file = os.path.join(cheatsheet_dir, f"{name}.md")
        
        if os.path.exists(output_file):
            print(f"Already exists: {output_file}")
            continue
        
        try:
            print(f"Downloading cheatsheet: {name}...")
            response = requests.get(url, timeout=30)
            response.raise_for_status()
            
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(response.text)
                
        except requests.exceptions.RequestException as e:
            print(f"Failed to download {url}: {e}")
    
    print(f"\nProgramming content downloaded to {OUTPUT_DIR}")

if __name__ == "__main__":
    download_programming_content()

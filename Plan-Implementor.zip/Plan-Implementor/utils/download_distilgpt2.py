#!/usr/bin/env python3
"""Download DistilGPT2 tokenizer files from HuggingFace."""

import os
import requests
from tqdm import tqdm

HF_BASE_URL = "https://huggingface.co/distilgpt2/resolve/main"
OUTPUT_DIR = "datasets/general/distilgpt2"

FILES_TO_DOWNLOAD = [
    "tokenizer.json",
    "vocab.json", 
    "merges.txt",
    "config.json",
    "tokenizer_config.json",
]

def download_distilgpt2():
    """Download DistilGPT2 tokenizer files."""
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    
    for filename in tqdm(FILES_TO_DOWNLOAD, desc="Downloading DistilGPT2 files"):
        output_file = os.path.join(OUTPUT_DIR, filename)
        
        if os.path.exists(output_file):
            print(f"Already exists: {output_file}")
            continue
        
        url = f"{HF_BASE_URL}/{filename}"
        print(f"\nDownloading {filename}...")
        
        try:
            response = requests.get(url, timeout=30)
            response.raise_for_status()
            
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(response.text)
            
            print(f"Downloaded: {output_file}")
            
        except requests.exceptions.RequestException as e:
            print(f"Failed to download {filename}: {e}")
    
    print(f"\nDistilGPT2 tokenizer files downloaded to {OUTPUT_DIR}")

if __name__ == "__main__":
    download_distilgpt2()

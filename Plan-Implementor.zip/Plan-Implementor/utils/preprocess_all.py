#!/usr/bin/env python3
"""
Run all preprocessing scripts and combine into training data.
"""

import subprocess
import sys
from pathlib import Path

SCRIPTS = [
    "utils/preprocess_attck.py",
    "utils/preprocess_cve.py", 
    "utils/preprocess_msf.py",
    "utils/preprocess_programming.py",
    "utils/preprocess_wiki.py",
    "utils/combine_datasets.py"
]

def main():
    print("="*60)
    print("Running all preprocessing scripts")
    print("="*60)
    
    for script in SCRIPTS:
        script_path = Path(script)
        
        if not script_path.exists():
            print(f"\nSkipping {script} (not found)")
            continue
        
        print(f"\n{'='*60}")
        print(f"Running: {script}")
        print("="*60)
        
        result = subprocess.run(
            [sys.executable, script],
            capture_output=False
        )
        
        if result.returncode != 0:
            print(f"Warning: {script} exited with code {result.returncode}")
    
    print("\n" + "="*60)
    print("Preprocessing complete!")
    print("="*60)
    
    train_file = Path("datasets/train.txt")
    if train_file.exists():
        size_mb = train_file.stat().st_size / (1024*1024)
        print(f"\nTraining data ready: {train_file}")
        print(f"Size: {size_mb:.2f} MB")
    else:
        print("\nNote: train.txt not created - run individual scripts first")

if __name__ == "__main__":
    main()

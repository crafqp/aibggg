#!/usr/bin/env python3
"""Master script to download all training data."""

import subprocess
import sys
import os

SCRIPTS = [
    "utils/download_distilgpt2.py",
    "utils/download_attck.py",
    "utils/download_programming.py",
    "utils/download_wiki.py",
    "utils/download_cve.py",
    "utils/download_msf.py",
]

def main():
    """Run all download scripts."""
    print("=" * 60)
    print("AI Model Training - Data Download")
    print("=" * 60)
    
    for script in SCRIPTS:
        if not os.path.exists(script):
            print(f"Script not found: {script}")
            continue
            
        print(f"\n{'=' * 60}")
        print(f"Running: {script}")
        print("=" * 60)
        
        try:
            result = subprocess.run(
                [sys.executable, script],
                check=True,
                capture_output=False
            )
        except subprocess.CalledProcessError as e:
            print(f"Error running {script}: {e}")
        except KeyboardInterrupt:
            print("\nDownload interrupted by user")
            sys.exit(1)
    
    print("\n" + "=" * 60)
    print("All downloads complete!")
    print("=" * 60)

if __name__ == "__main__":
    main()

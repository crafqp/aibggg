#!/usr/bin/env python3
"""
Preprocess MITRE ATT&CK JSON data into clean training text.
Extracts technique names, descriptions, and detection info.
"""

import json
import os
import re
from pathlib import Path

INPUT_DIR = Path("datasets/cybersec/attck")
OUTPUT_DIR = Path("datasets/clean")

def clean_text(text):
    """Remove citations, extra whitespace, and clean formatting."""
    if not text:
        return ""
    text = re.sub(r'\(Citation:[^)]+\)', '', text)
    text = re.sub(r'\[([^\]]+)\]\([^)]+\)', r'\1', text)
    text = re.sub(r'<[^>]+>', '', text)
    text = re.sub(r'\s+', ' ', text)
    return text.strip()

def extract_techniques(data):
    """Extract attack techniques with descriptions."""
    entries = []
    objects = data.get("objects", [])
    
    for obj in objects:
        obj_type = obj.get("type", "")
        
        if obj_type == "attack-pattern":
            name = obj.get("name", "")
            description = clean_text(obj.get("description", ""))
            
            if name and description:
                entry = f"ATT&CK Technique: {name}\n{description}"
                
                kill_chain = obj.get("kill_chain_phases", [])
                if kill_chain:
                    phases = [p.get("phase_name", "") for p in kill_chain]
                    entry += f"\nTactics: {', '.join(phases)}"
                
                entries.append(entry)
        
        elif obj_type == "malware" or obj_type == "tool":
            name = obj.get("name", "")
            description = clean_text(obj.get("description", ""))
            
            if name and description:
                label = "Malware" if obj_type == "malware" else "Tool"
                entries.append(f"ATT&CK {label}: {name}\n{description}")
        
        elif obj_type == "intrusion-set":
            name = obj.get("name", "")
            description = clean_text(obj.get("description", ""))
            
            if name and description:
                entries.append(f"Threat Group: {name}\n{description}")
    
    return entries

def main():
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    
    all_entries = []
    
    for json_file in INPUT_DIR.glob("*.json"):
        print(f"Processing {json_file.name}...")
        with open(json_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        entries = extract_techniques(data)
        all_entries.extend(entries)
        print(f"  Extracted {len(entries)} entries")
    
    DELIMITER = "\n\n<|ENTRY_SEP|>\n\n"
    
    output_file = OUTPUT_DIR / "attck_clean.txt"
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(DELIMITER.join(all_entries))
    
    print(f"\nTotal: {len(all_entries)} entries written to {output_file}")
    print(f"File size: {output_file.stat().st_size / 1024:.1f} KB")

if __name__ == "__main__":
    main()

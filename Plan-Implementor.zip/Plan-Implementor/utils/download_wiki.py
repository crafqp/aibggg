#!/usr/bin/env python3
"""Download Simple Wikipedia dump for training data."""

import os
import requests
from tqdm import tqdm

WIKI_DUMP_URL = "https://dumps.wikimedia.org/simplewiki/latest/simplewiki-latest-pages-articles.xml.bz2"
OUTPUT_DIR = "datasets/general/wiki"
OUTPUT_FILE = os.path.join(OUTPUT_DIR, "simplewiki-latest-pages-articles.xml.bz2")

def download_wiki():
    """Download Simple Wikipedia dump."""
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    
    if os.path.exists(OUTPUT_FILE):
        print(f"File already exists: {OUTPUT_FILE}")
        return
    
    print(f"Downloading Simple Wikipedia dump from {WIKI_DUMP_URL}")
    
    response = requests.get(WIKI_DUMP_URL, stream=True)
    response.raise_for_status()
    
    total_size = int(response.headers.get('content-length', 0))
    
    with open(OUTPUT_FILE, 'wb') as f:
        with tqdm(total=total_size, unit='B', unit_scale=True, desc="Downloading") as pbar:
            for chunk in response.iter_content(chunk_size=8192):
                if chunk:
                    f.write(chunk)
                    pbar.update(len(chunk))
    
    print(f"Downloaded to: {OUTPUT_FILE}")
    print(f"File size: {os.path.getsize(OUTPUT_FILE) / (1024*1024):.2f} MB")

if __name__ == "__main__":
    download_wiki()

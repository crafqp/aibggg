#!/usr/bin/env python3
"""Download Metasploit module files (Ruby text only)."""

import os
import requests
import zipfile
from io import BytesIO
from tqdm import tqdm

MSF_REPO_URL = "https://github.com/rapid7/metasploit-framework/archive/refs/heads/master.zip"
OUTPUT_DIR = "datasets/cybersec/msf"
TEMP_ZIP = "datasets/raw/msf_temp.zip"

def download_msf_modules():
    """Download Metasploit Ruby modules as text files."""
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    os.makedirs("datasets/raw", exist_ok=True)
    
    modules_exist = any(f.endswith('.rb') for f in os.listdir(OUTPUT_DIR)) if os.path.exists(OUTPUT_DIR) else False
    if modules_exist:
        print(f"Metasploit modules already downloaded to {OUTPUT_DIR}")
        return
    
    print(f"Downloading Metasploit framework (this may take a while)...")
    
    response = requests.get(MSF_REPO_URL, stream=True)
    response.raise_for_status()
    
    total_size = int(response.headers.get('content-length', 0))
    
    with open(TEMP_ZIP, 'wb') as f:
        with tqdm(total=total_size, unit='B', unit_scale=True, desc="Downloading") as pbar:
            for chunk in response.iter_content(chunk_size=8192):
                if chunk:
                    f.write(chunk)
                    pbar.update(len(chunk))
    
    print("Extracting module files...")
    
    module_count = 0
    with zipfile.ZipFile(TEMP_ZIP, 'r') as zf:
        for name in tqdm(zf.namelist(), desc="Extracting modules"):
            if '/modules/' in name and name.endswith('.rb'):
                content = zf.read(name).decode('utf-8', errors='ignore')
                
                relative_name = name.split('/modules/')[-1]
                out_path = os.path.join(OUTPUT_DIR, relative_name)
                os.makedirs(os.path.dirname(out_path), exist_ok=True)
                
                with open(out_path, 'w', encoding='utf-8') as f:
                    f.write(content)
                module_count += 1
    
    os.remove(TEMP_ZIP)
    print(f"Extracted {module_count} module files to {OUTPUT_DIR}")

if __name__ == "__main__":
    download_msf_modules()

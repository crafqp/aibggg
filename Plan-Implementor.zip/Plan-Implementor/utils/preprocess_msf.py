#!/usr/bin/env python3
"""
Preprocess Metasploit module files into clean training text.
Extracts module descriptions, options, and documentation from Ruby files.
"""

import os
import re
from pathlib import Path

INPUT_DIR = Path("datasets/cybersec/msf")
OUTPUT_DIR = Path("datasets/clean")

def extract_module_info(content, filepath):
    """Extract useful information from a Metasploit module."""
    info = {
        'name': '',
        'description': '',
        'author': '',
        'references': [],
        'options': []
    }
    
    name_match = re.search(r"'Name'\s*=>\s*['\"](.+?)['\"]", content)
    if name_match:
        info['name'] = name_match.group(1)
    
    desc_match = re.search(r"'Description'\s*=>\s*%q\{(.+?)\}", content, re.DOTALL)
    if not desc_match:
        desc_match = re.search(r"'Description'\s*=>\s*['\"](.+?)['\"]", content, re.DOTALL)
    if desc_match:
        desc = desc_match.group(1)
        desc = re.sub(r'\s+', ' ', desc).strip()
        info['description'] = desc
    
    author_match = re.search(r"'Author'\s*=>\s*\[([^\]]+)\]", content, re.DOTALL)
    if author_match:
        authors = re.findall(r"['\"]([^'\"]+)['\"]", author_match.group(1))
        info['author'] = ', '.join(authors[:3])
    
    refs = re.findall(r"\[\s*['\"](\w+)['\"]\s*,\s*['\"]([^'\"]+)['\"]\s*\]", content)
    for ref_type, ref_val in refs[:5]:
        if ref_type in ['CVE', 'EDB', 'URL', 'OSVDB']:
            info['references'].append(f"{ref_type}: {ref_val}")
    
    opts = re.findall(r"OptString\.new\(['\"](\w+)['\"].*?['\"]([^'\"]+)['\"]", content)
    opts += re.findall(r"OptInt\.new\(['\"](\w+)['\"].*?['\"]([^'\"]+)['\"]", content)
    opts += re.findall(r"OptBool\.new\(['\"](\w+)['\"].*?['\"]([^'\"]+)['\"]", content)
    for opt_name, opt_desc in opts[:10]:
        info['options'].append(f"{opt_name}: {opt_desc}")
    
    return info

def format_entry(info, filepath):
    """Format module info as training text."""
    if not info['name'] and not info['description']:
        return None
    
    rel_path = filepath.relative_to(INPUT_DIR)
    parts = rel_path.parts
    
    if len(parts) >= 2:
        module_type = parts[0]
    else:
        module_type = "module"
    
    lines = [f"Metasploit {module_type.title()} Module: {info['name'] or filepath.stem}"]
    
    if info['description']:
        lines.append(f"\n{info['description']}")
    
    if info['author']:
        lines.append(f"\nAuthor: {info['author']}")
    
    if info['references']:
        lines.append(f"\nReferences: {', '.join(info['references'])}")
    
    if info['options']:
        lines.append(f"\nOptions:\n" + '\n'.join(f"  - {opt}" for opt in info['options']))
    
    return '\n'.join(lines)

def main():
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    
    all_entries = []
    
    rb_files = list(INPUT_DIR.rglob("*.rb"))
    
    if not rb_files:
        print("No Metasploit modules found. Run download_msf.py first.")
        return
    
    print(f"Found {len(rb_files)} Ruby files to process...")
    
    for i, rb_file in enumerate(rb_files):
        if i % 100 == 0:
            print(f"Processing {i}/{len(rb_files)}...")
        
        try:
            with open(rb_file, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            info = extract_module_info(content, rb_file)
            entry = format_entry(info, rb_file)
            
            if entry:
                all_entries.append(entry)
        
        except Exception as e:
            continue
    
    if not all_entries:
        print("No module information extracted.")
        return
    
    DELIMITER = "\n\n<|ENTRY_SEP|>\n\n"
    
    output_file = OUTPUT_DIR / "msf_clean.txt"
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(DELIMITER.join(all_entries))
    
    print(f"\nTotal: {len(all_entries)} modules written to {output_file}")
    print(f"File size: {output_file.stat().st_size / 1024:.1f} KB")

if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Download CVE JSON feeds from NVD."""

import os
import json
import gzip
import requests
from io import BytesIO
from tqdm import tqdm

NVD_FEED_BASE = "https://nvd.nist.gov/feeds/json/cve/1.1"
YEARS = [2021, 2022, 2023, 2024]
OUTPUT_DIR = "datasets/cybersec/cve"

def download_cve_feeds():
    """Download CVE JSON feeds for recent years."""
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    
    for year in tqdm(YEARS, desc="Downloading CVE feeds"):
        output_file = os.path.join(OUTPUT_DIR, f"nvdcve-1.1-{year}.json")
        
        if os.path.exists(output_file):
            print(f"File already exists: {output_file}")
            continue
        
        url = f"{NVD_FEED_BASE}/nvdcve-1.1-{year}.json.gz"
        print(f"\nDownloading CVE feed for {year}...")
        
        try:
            response = requests.get(url, timeout=60)
            response.raise_for_status()
            
            with gzip.GzipFile(fileobj=BytesIO(response.content)) as gz:
                data = json.loads(gz.read().decode('utf-8'))
            
            with open(output_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2)
            
            cve_count = len(data.get('CVE_Items', []))
            print(f"Downloaded {cve_count} CVEs for {year}")
            
        except requests.exceptions.RequestException as e:
            print(f"Failed to download {year}: {e}")
            alt_url = f"https://github.com/CVEProject/cvelistV5/archive/refs/heads/main.zip"
            print(f"Note: NVD feeds may be deprecated. Consider CVE List V5: {alt_url}")

if __name__ == "__main__":
    download_cve_feeds()

#!/usr/bin/env python3
"""Download MITRE ATT&CK framework data."""

import os
import json
import requests

ATTCK_URLS = {
    "enterprise": "https://raw.githubusercontent.com/mitre/cti/master/enterprise-attack/enterprise-attack.json",
    "mobile": "https://raw.githubusercontent.com/mitre/cti/master/mobile-attack/mobile-attack.json",
    "ics": "https://raw.githubusercontent.com/mitre/cti/master/ics-attack/ics-attack.json",
}

OUTPUT_DIR = "datasets/cybersec/attck"

def download_attck():
    """Download MITRE ATT&CK JSON files."""
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    
    for name, url in ATTCK_URLS.items():
        output_file = os.path.join(OUTPUT_DIR, f"{name}-attack.json")
        
        if os.path.exists(output_file):
            print(f"File already exists: {output_file}")
            continue
        
        print(f"Downloading {name} ATT&CK data...")
        
        response = requests.get(url)
        response.raise_for_status()
        
        data = response.json()
        
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2)
        
        print(f"Downloaded to: {output_file}")
        print(f"Objects: {len(data.get('objects', []))}")

if __name__ == "__main__":
    download_attck()

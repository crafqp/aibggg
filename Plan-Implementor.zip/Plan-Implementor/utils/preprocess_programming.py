#!/usr/bin/env python3
"""
Preprocess programming tutorials (Markdown files) into clean training text.
Removes excessive markdown formatting while preserving code structure.
"""

import os
import re
from pathlib import Path

INPUT_DIR = Path("datasets/programming")
OUTPUT_DIR = Path("datasets/clean")

def clean_markdown(text):
    """Convert markdown to clean text while preserving code blocks."""
    lines = text.split('\n')
    result = []
    in_code_block = False
    code_lang = ""
    
    for line in lines:
        if line.startswith('```'):
            if not in_code_block:
                in_code_block = True
                code_lang = line[3:].strip()
                if code_lang:
                    result.append(f"\n[{code_lang.upper()} CODE]")
                else:
                    result.append("\n[CODE]")
            else:
                in_code_block = False
                result.append("[END CODE]\n")
            continue
        
        if in_code_block:
            result.append(line)
            continue
        
        line = re.sub(r'^#{1,6}\s+', '', line)
        line = re.sub(r'\*\*([^*]+)\*\*', r'\1', line)
        line = re.sub(r'\*([^*]+)\*', r'\1', line)
        line = re.sub(r'`([^`]+)`', r'\1', line)
        line = re.sub(r'\[([^\]]+)\]\([^)]+\)', r'\1', line)
        line = re.sub(r'^\s*[-*+]\s+', '- ', line)
        line = re.sub(r'^\s*\d+\.\s+', '', line)
        
        result.append(line)
    
    text = '\n'.join(result)
    text = re.sub(r'\n{3,}', '\n\n', text)
    
    return text.strip()

def process_file(filepath):
    """Process a single markdown file."""
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
        
        if len(content) < 100:
            return None
        
        cleaned = clean_markdown(content)
        
        rel_path = filepath.relative_to(INPUT_DIR)
        topic = rel_path.parts[0] if rel_path.parts else "general"
        
        header = f"Programming Tutorial ({topic.upper()})"
        return f"{header}\n\n{cleaned}"
    
    except Exception as e:
        print(f"  Error processing {filepath}: {e}")
        return None

def main():
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    
    all_entries = []
    
    for md_file in INPUT_DIR.rglob("*.md"):
        print(f"Processing {md_file}...")
        entry = process_file(md_file)
        if entry:
            all_entries.append(entry)
            print(f"  Extracted {len(entry)} chars")
    
    DELIMITER = "\n\n<|ENTRY_SEP|>\n\n"
    
    output_file = OUTPUT_DIR / "programming_clean.txt"
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(DELIMITER.join(all_entries))
    
    print(f"\nTotal: {len(all_entries)} tutorials written to {output_file}")
    print(f"File size: {output_file.stat().st_size / 1024:.1f} KB")

if __name__ == "__main__":
    main()

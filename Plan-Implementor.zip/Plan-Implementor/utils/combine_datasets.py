#!/usr/bin/env python3
"""
Combine all preprocessed datasets into a single training file.
Creates train.txt ready for tokenization and model training.
"""

import os
import random
from pathlib import Path

CLEAN_DIR = Path("datasets/clean")
OUTPUT_DIR = Path("datasets")

DELIMITER = "\n\n<|ENTRY_SEP|>\n\n"

def load_clean_file(filepath):
    """Load and split a clean data file into entries."""
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
        
        entries = content.split(DELIMITER)
        entries = [e.strip() for e in entries if e.strip()]
        return entries
    except Exception as e:
        print(f"Error loading {filepath}: {e}")
        return []

def main():
    CLEAN_DIR.mkdir(parents=True, exist_ok=True)
    
    all_entries = []
    sources = {}
    
    clean_files = list(CLEAN_DIR.glob("*_clean.txt"))
    
    if not clean_files:
        print("No preprocessed files found in datasets/clean/")
        print("Run the individual preprocess scripts first:")
        print("  - python utils/preprocess_attck.py")
        print("  - python utils/preprocess_cve.py")
        print("  - python utils/preprocess_msf.py")
        print("  - python utils/preprocess_programming.py")
        print("  - python utils/preprocess_wiki.py")
        return
    
    for clean_file in clean_files:
        source_name = clean_file.stem.replace('_clean', '')
        print(f"Loading {clean_file.name}...")
        
        entries = load_clean_file(clean_file)
        sources[source_name] = len(entries)
        all_entries.extend(entries)
        print(f"  Loaded {len(entries)} entries")
    
    print(f"\nShuffling {len(all_entries)} total entries...")
    random.seed(42)
    random.shuffle(all_entries)
    
    train_file = OUTPUT_DIR / "train.txt"
    with open(train_file, 'w', encoding='utf-8') as f:
        for entry in all_entries:
            f.write(entry)
            f.write("\n\n<|endoftext|>\n\n")
    
    print(f"\n{'='*50}")
    print("Dataset Statistics:")
    print(f"{'='*50}")
    
    for source, count in sorted(sources.items()):
        print(f"  {source}: {count:,} entries")
    
    print(f"\nTotal: {len(all_entries):,} entries")
    print(f"Output: {train_file}")
    print(f"Size: {train_file.stat().st_size / (1024*1024):.2f} MB")
    
    with open(train_file, 'r', encoding='utf-8') as f:
        char_count = len(f.read())
    print(f"Characters: {char_count:,}")
    
    approx_tokens = char_count // 4
    print(f"Approx tokens: {approx_tokens:,}")

if __name__ == "__main__":
    main()

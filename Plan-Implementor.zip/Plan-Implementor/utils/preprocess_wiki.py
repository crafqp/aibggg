#!/usr/bin/env python3
"""
Preprocess Wikipedia XML dump into clean training text.
Extracts article titles and content, removes wiki markup.
"""

import bz2
import re
import xml.etree.ElementTree as ET
from pathlib import Path
from html import unescape

INPUT_DIR = Path("datasets/general/wiki")
OUTPUT_DIR = Path("datasets/clean")

def clean_wikitext(text):
    """Remove wiki markup and convert to plain text."""
    text = re.sub(r'\[\[Category:[^\]]+\]\]', '', text)
    text = re.sub(r'\[\[File:[^\]]+\]\]', '', text)
    text = re.sub(r'\[\[Image:[^\]]+\]\]', '', text)
    
    text = re.sub(r'\[\[([^|\]]+)\|([^\]]+)\]\]', r'\2', text)
    text = re.sub(r'\[\[([^\]]+)\]\]', r'\1', text)
    
    text = re.sub(r'\[https?://[^\s\]]+\s+([^\]]+)\]', r'\1', text)
    text = re.sub(r'\[https?://[^\]]+\]', '', text)
    
    text = re.sub(r"'''([^']+)'''", r'\1', text)
    text = re.sub(r"''([^']+)''", r'\1', text)
    
    text = re.sub(r'\{\{[^}]+\}\}', '', text)
    
    text = re.sub(r'<ref[^>]*>.*?</ref>', '', text, flags=re.DOTALL)
    text = re.sub(r'<ref[^/]*/>', '', text)
    text = re.sub(r'<[^>]+>', '', text)
    
    text = re.sub(r'^\s*\|.*$', '', text, flags=re.MULTILINE)
    text = re.sub(r'^\s*\{[|!].*$', '', text, flags=re.MULTILINE)
    text = re.sub(r'^\s*[|!}\-].*$', '', text, flags=re.MULTILINE)
    
    text = re.sub(r'^=+\s*([^=]+)\s*=+$', r'\n\1\n', text, flags=re.MULTILINE)
    
    text = unescape(text)
    text = re.sub(r'&[a-zA-Z]+;', '', text)
    
    text = re.sub(r'\n{3,}', '\n\n', text)
    text = re.sub(r' +', ' ', text)
    
    return text.strip()

def extract_articles(xml_content, max_articles=10000):
    """Extract articles from Wikipedia XML."""
    articles = []
    
    try:
        for event, elem in ET.iterparse(xml_content, events=['end']):
            if elem.tag.endswith('page'):
                title_elem = elem.find('.//{http://www.mediawiki.org/xml/export-0.10/}title')
                if title_elem is None:
                    title_elem = elem.find('.//title')
                
                text_elem = elem.find('.//{http://www.mediawiki.org/xml/export-0.10/}text')
                if text_elem is None:
                    text_elem = elem.find('.//text')
                
                if title_elem is not None and text_elem is not None:
                    title = title_elem.text or ""
                    text = text_elem.text or ""
                    
                    if ':' not in title and len(text) > 500:
                        if not text.startswith('#REDIRECT'):
                            cleaned = clean_wikitext(text)
                            if len(cleaned) > 200:
                                articles.append(f"Wikipedia: {title}\n\n{cleaned}")
                                
                                if len(articles) >= max_articles:
                                    return articles
                
                elem.clear()
    
    except ET.ParseError as e:
        print(f"XML parsing error: {e}")
    
    return articles

def main():
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    
    all_articles = []
    
    bz2_files = list(INPUT_DIR.glob("*.xml.bz2"))
    xml_files = list(INPUT_DIR.glob("*.xml"))
    
    for bz2_file in bz2_files:
        print(f"Processing {bz2_file.name}...")
        try:
            with bz2.open(bz2_file, 'rt', encoding='utf-8') as f:
                articles = extract_articles(f)
                all_articles.extend(articles)
                print(f"  Extracted {len(articles)} articles")
        except Exception as e:
            print(f"  Error: {e}")
    
    for xml_file in xml_files:
        print(f"Processing {xml_file.name}...")
        try:
            with open(xml_file, 'r', encoding='utf-8') as f:
                articles = extract_articles(f)
                all_articles.extend(articles)
                print(f"  Extracted {len(articles)} articles")
        except Exception as e:
            print(f"  Error: {e}")
    
    if not all_articles:
        print("\nNo Wikipedia data found. Run download_wiki.py first.")
        return
    
    DELIMITER = "\n\n<|ENTRY_SEP|>\n\n"
    
    output_file = OUTPUT_DIR / "wiki_clean.txt"
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(DELIMITER.join(all_articles))
    
    print(f"\nTotal: {len(all_articles)} articles written to {output_file}")
    print(f"File size: {output_file.stat().st_size / 1024:.1f} KB")

if __name__ == "__main__":
    main()

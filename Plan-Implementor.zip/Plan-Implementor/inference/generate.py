#!/usr/bin/env python3
"""
Inference script for text generation using the trained GPT model.
"""
import os
import sys
import argparse
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from training.model import GPTModel

def decode_bytes(token_ids):
    """Decode byte-level token IDs back to text."""
    return bytes(token_ids).decode('utf-8', errors='replace')

def encode_bytes(text):
    """Encode text to byte-level token IDs."""
    return list(text.encode('utf-8', errors='replace'))

def generate_text(
    model_path,
    prompt="",
    max_tokens=100,
    temperature=1.0,
    top_k=None,
):
    """Generate text using a trained model."""
    print(f"Loading model from {model_path}...")
    model = GPTModel.load(model_path)
    print(f"Model loaded: {model.n_params:,} parameters")
    
    if prompt:
        input_ids = encode_bytes(prompt)
        print(f"\nPrompt: {prompt}")
    else:
        input_ids = [ord('\n')]
        print("\nStarting with newline character...")
    
    idx = np.array([input_ids])
    
    print(f"\nGenerating {max_tokens} tokens (temp={temperature}, top_k={top_k})...")
    print("-" * 50)
    
    generated_ids = model.generate(
        idx,
        max_new_tokens=max_tokens,
        temperature=temperature,
        top_k=top_k,
    )
    
    output_ids = generated_ids[0].tolist()
    output_text = decode_bytes(output_ids)
    
    print(output_text)
    print("-" * 50)
    
    return output_text

def interactive_mode(model_path, temperature=1.0, top_k=40):
    """Interactive text generation mode."""
    print(f"Loading model from {model_path}...")
    model = GPTModel.load(model_path)
    print(f"Model loaded: {model.n_params:,} parameters")
    print("\nInteractive mode. Type 'quit' to exit.")
    print("Enter a prompt to generate text.\n")
    
    while True:
        try:
            prompt = input(">>> ")
            if prompt.lower() in ['quit', 'exit', 'q']:
                break
            if not prompt:
                continue
                
            input_ids = encode_bytes(prompt)
            idx = np.array([input_ids])
            
            generated_ids = model.generate(
                idx,
                max_new_tokens=50,
                temperature=temperature,
                top_k=top_k,
            )
            
            output_ids = generated_ids[0].tolist()
            output_text = decode_bytes(output_ids)
            print(f"\n{output_text}\n")
            
        except KeyboardInterrupt:
            print("\nExiting...")
            break
        except Exception as e:
            print(f"Error: {e}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Generate text with trained GPT model")
    parser.add_argument("--model", default="model/checkpoints/best_model.json", 
                       help="Path to model checkpoint")
    parser.add_argument("--prompt", default="", help="Text prompt to start generation")
    parser.add_argument("--max-tokens", type=int, default=100, help="Max tokens to generate")
    parser.add_argument("--temperature", type=float, default=1.0, help="Sampling temperature")
    parser.add_argument("--top-k", type=int, default=None, help="Top-k sampling")
    parser.add_argument("--interactive", action="store_true", help="Interactive mode")
    args = parser.parse_args()
    
    if not os.path.exists(args.model):
        print(f"Error: Model not found at {args.model}")
        print("Train a model first using: python training/train.py")
        sys.exit(1)
    
    if args.interactive:
        interactive_mode(args.model, args.temperature, args.top_k or 40)
    else:
        generate_text(
            model_path=args.model,
            prompt=args.prompt,
            max_tokens=args.max_tokens,
            temperature=args.temperature,
            top_k=args.top_k,
        )
